class Contato < ActiveRecord::Base
end
